package coms.HappyFeet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappyFeetApplication {

	public static void main(String[] args) {
		SpringApplication.run(HappyFeetApplication.class, args);
		System.out.println("Server Started....");
	}

}
