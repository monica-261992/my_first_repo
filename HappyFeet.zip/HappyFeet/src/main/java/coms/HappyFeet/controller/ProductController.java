package coms.HappyFeet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import coms.HappyFeet.service.*;

@RestController
public class ProductController {

		@Autowired
		private ProductService productService;
}
