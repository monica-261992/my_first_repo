package coms.HappyFeet.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import coms.HappyFeet.model.PurchaseOrder;



public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder, Long> {
	
	

}
