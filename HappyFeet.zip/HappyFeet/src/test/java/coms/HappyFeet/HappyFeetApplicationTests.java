package coms.HappyFeet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HappyFeetApplicationTests {

	@Test
	void contextLoads() {
	}

}
